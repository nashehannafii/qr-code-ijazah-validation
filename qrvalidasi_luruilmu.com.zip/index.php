<?php include "header.php"; ?>
<div class="container">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"><span class="glyphicon glyphicon-home"></span> Universitas LuruIlmu.Com</h3>
		</div>
		<div class="panel-body">
            <center>
			    <img src="assets/img/logo.png" alt="..." class="img-thumbnail">
            </center>
		</div>
		<div class="panel-footer">
			
		</div>
	</div>
</div>

<?php include "footer.php"; ?>
