
	<footer class="footer">
      <div class="container">
        <p class="text-muted"><a href="https://luruilmu.com" target="_blank">Luruilmu.com</a> Tahun 2018</p>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="./assets/js/jquery.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
</body>
</html>